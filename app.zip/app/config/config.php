<?php 

define('BASEURL', 'http://sirvice/public');
define('PROFILE_IMAGE', 'http://sirvice/public/image/user-profile/');

// DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sirvice');

// FILE UPLOAD
define('PROFILE_PATH',$_SERVER['DOCUMENT_ROOT'] . '/public/image/user-profile/');

define('PAYMENT_PATH',$_SERVER['DOCUMENT_ROOT'] . '/app/uploads/payment/');