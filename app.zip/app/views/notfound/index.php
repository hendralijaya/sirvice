<main>
  <section id ="notfound">
    <div class="notfound-image">
      <img src="<?= BASEURL; ?>/image/NotFound.png" alt="Not Found Image">
    </div>
    <div class="notfound-text">
      <h2>404 - Page Not Found</h2>
      <p>We're sorry that you couldn’t find what you’re looking for.</p>
      <a href="<?= BASEURL; ?>">Back to Home</a>
    </div>
  </section>
</main>