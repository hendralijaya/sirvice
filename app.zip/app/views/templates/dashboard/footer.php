    <div id="preloader">
        <div class="lds-ellipsis">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    
    <script src="<?= BASEURL; ?>/js/script.js"></script>
    <script src="<?= BASEURL; ?>/js/script-password-field.js"></script>
    <script src="<?= BASEURL; ?>/js/script-loader.js"></script>
    <script src="<?= BASEURL; ?>/js/script-address-search.js"></script>
    <script src="<?= BASEURL; ?>/js/script-tips-search.js"></script>
    <script src="<?= BASEURL; ?>/js/script-modal.js"></script>
    <script src="<?= BASEURL; ?>/js/script-modal-feedback.js"></script>
    <script src="<?= BASEURL; ?>/js/script-sidebar.js"></script>
    <script src="<?= BASEURL; ?>/js/script-status-order-info.js"></script>
    <script src="<?= BASEURL; ?>/js/script-stepper.js"></script>
    <script src="<?= BASEURL; ?>/js/script-tab-dashboard.js"></script>
    <script src="<?= BASEURL; ?>/js/script-change-image.js"></script>
    <script src="<?= BASEURL; ?>/js/script-alert.js"></script>
    <script src="<?= BASEURL; ?>/js/script-payment.js"></script>
</body>
</html>